package ar.jornadas.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.*
import ar.jornadas.Servicios
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.IOException

class ProgramaModel(app: Application, private val estado: SavedStateHandle) : AndroidViewModel(app) {
    private val servicios = Servicios(app)
    val mesa = servicios.mesa
    private val repo = servicios.agenda
    private val preferencias = app.getSharedPreferences("agenda", Context.MODE_PRIVATE)

    val hayEdicionGuardada = MutableStateFlow(
        preferencias.getBoolean("hay_edicion_guardada", false)
    )
    val charlas = repo.programa.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val dia = estado.getStateFlow("dia", 0)
    val tema = estado.getStateFlow("tema", "Todos")
    val aviso = MutableStateFlow("")
    val cargando = MutableStateFlow(false)


    fun cargarAlIniciar() {
        if (cargaAutomaticaHecha) return
        cargaAutomaticaHecha = true
        recargar()
    }

    fun recargar() {
        if (cargando.value) return
        cargando.value = true
        viewModelScope.launch {
            aviso.value = ""

            try {
                repo.sincronizar()

                preferencias.edit()
                    .putBoolean("hay_edicion_guardada", true)
                    .apply()

                hayEdicionGuardada.value = true

            } catch (e: IOException) {
                aviso.value = if (hayEdicionGuardada.value) {
                    "No se pudo actualizar el programa. Se están usando los datos guardados."
                } else {
                    "No se pudo descargar el programa. Todavía no hay datos guardados."
                }
            } finally {
                cargando.value = false
            }
        }
    }


    fun elegirDia(valor: Int) { estado["dia"] = valor }
    fun elegirTema(valor: String) { estado["tema"] = valor }
    fun marcar(id: String) { viewModelScope.launch { repo.cambiarFavorita(id) } }

    companion object {
        private var cargaAutomaticaHecha = false
    }
}